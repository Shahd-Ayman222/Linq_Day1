﻿using System.Globalization;
using System.Collections;
using System.Collections.Generic;
namespace Linq_Day1;

class Program
{
    static void Main(string[] args)
    {
        #region part1)

        //Q1 
        // var x = 10;
        // var y = 10.9;
        // var name = "shahd";
        // var a = true;
        // var arr =new []{10, 20, 3, 50};
        // Console.WriteLine(x.GetType().Name);
        // Console.WriteLine(y.GetType().Name);
        // Console.WriteLine(name.GetType().Name);
        // Console.WriteLine(a.GetType().Name);
        // Console.WriteLine(arr.GetType().Name);
        //Q2)
        // int x = 10;
        // string name = "shahd";
        // double y = 123.45;
        // var x2 = 10;
        // var name2 = "ali";
        // var y2 = 1093.9;
        // var knowing the type's assigned in compile time
        //explicit also knowing the type in compile time 

        #endregion
        #region part2)

        // var product = new
        // {
        //     Name = "Laptop",
        //     Price = 25000,
        //     Quantity = 5,
        //
        // };
        // Console.WriteLine($"ProductName: {product.Name} , Price: {product.Price} , Quantity: {product.Quantity}");
        //-----------------------
        // var array = new[]
        // {
        //     new { Name = "shahd", Grade = 90 },
        //     new { Name = "ali", Grade = 80 },
        //     new { Name = "alaa", Grade = 70 },
        // };
        // foreach (var i in array)
        // {
        //     Console.WriteLine(i); // anonymous make override tostring method 
        // }
        //--------------------------
        // var Order = new
        // {
        //     Name = "Laptop Order",
        //     Id = "3",
        //     OrderQuantity = 2,
        //     Customer = new
        //     {
        //         Name = "Ahmed",
        //         Address = new
        //         {
        //             Country = "Egypt",
        //             City = "cairo"
        //         }
        //     }
        // };
        // Console.WriteLine(Order.Name+", "+Order.OrderQuantity+", "+Order.Id+" , "+Order.Customer.Name+", "+Order.Customer.Address.Country+", "+Order.Customer.Address.City);
        //

        #endregion
        #region part3)

        // string s = "ala";
        // Console.WriteLine(s.IsPalind());
        // int num = 9;
        // Console.WriteLine(num.IsPrime());
        // int[] arr = { 10, 20, 30 };
        // Console.WriteLine(arr.Sum());

        #endregion
        #region part4

        List<Employee> l1 = new List<Employee>(3);
        l1.Add(new Employee("shahd", 10000));
        l1.Add(new Employee("Ayman", 50000));
        l1.Add(new Employee("Mohamed", 8000));
        l1.Add(new Employee("James", 2000));
        l1.Add(new Employee("Michael", 3000));
        l1.RemoveAt(2);
        //foreach (Employee e in l1)
        // var res = l1.Find(x => x.Name == "shahd");
        // Console.WriteLine(res);
        // foreach (var item in l1)
        // {
        //     if (item.Name == "shahd")
        //     {
        //         Console.WriteLine("name's found");
        //         return;
        //     }
        // }
        // Console.WriteLine("name's not found");
        //------------------------
        // foreach (var item in l1)
        // {
        //     if (item.Salary > 5000)
        //     {
        //         Console.WriteLine(item);
        //     }
        // }
        // //another way
        // Console.WriteLine("======================");
        // var res=l1.
        //     Where(x => x.Salary < 5000).ToList();
        // foreach (var item in res)
        // {
        //     Console.WriteLine(item);
        // }
        //-------------------------------------

        #endregion
        #region part4 Dictonary:

        Dictionary<string, int> d1 = new Dictionary<string, int>()
        {
            { "Laptop", 25000 },
            { "Mouse", 500 },
            { "Keyboard", 1000 }
        };
        // foreach (var i in d1) 
        // {
        //     Console.WriteLine($"ProductName: {i.Key} , Price: {i.Value}");
        // }
        //---------------------------------------
        // var res=d1.Select(x=>new
        // {
        //     Name=x.Key,
        //     Price=x.Value
        // }).ToList();
        // foreach (var i in res)
        // {
        //     Console.WriteLine(i);
        // }
        //-----------------------------


        #endregion
        #region Dictonary2
        // Dictionary<int, string> d2 = new Dictionary<int, string>()
        // {
        //     { 1, "amal" },
        //     { 2, "shahd" },
        //     { 3, "ayman" },
        //     { 4, "mohamed" },
        //
        // };
        // // bool isfound=d2.TryGetValue(8,out string val );
        // // if (isfound)
        // // {
        // //     Console.WriteLine(val);
        // // }
        // // else
        // // {
        // //     Console.WriteLine("value not found");
        // // }
        #endregion
        #region Q13
        // Hashtable h1 = new Hashtable();
        // h1.Add(1, "Shahd");
        // h1.Add(2, "Ayman");
        // h1.Add(3, "Mohamed");
        // foreach (DictionaryEntry item in h1)
        // {
        //     Console.WriteLine($"Key: {item.Key}, Value: {item.Value}");
        // }
       #endregion
        #region Q14
        // Hashtable h2= new Hashtable();
        // h2.Add("Student1", "Shahd");
        // h2.Add("Student2", "Ayman");
        // h2.Add("Student3", "Mohamed");
        // foreach (DictionaryEntry item in h2)
        // {
        //     Console.WriteLine($"Key: {item.Key}, Value: {item.Value}");
        // }
        // Dictionary<string, string> d3 = new Dictionary<string, string>();
        // d3.Add("Student1", "Shahd");
        // d3.Add("Student2", "Ayman");
        // d3.Add("Student3", "Mohamed");
        // //dictonary genric type,hashtable non generic
        #endregion
        



    }
}

public static class ExtensionMethod
{
    public static bool IsPalind(this string s)
    {
        string rev = "";
        for(int i=s.Length-1; i>=0; i--)
        {
            rev+=s[i];
            
        }
        return rev.Equals(s);
    }

    public static bool IsPrime(this int i)
    {
        if (i < 2)
            return false;
        for (int j = 2; j < i; j++)
        {
            if (i % j == 0)
                return false;
        }
        return true;
    }

    public static int Sum(this int []arr)
    {
        int sum = 0;
        foreach (int i in arr)
        {
            sum += i;
        }
        return sum;
    }
    }

public class Employee
{
    public string Name { get; set; }
    public double Salary { get; set; }

    public Employee(string name, double salary)
    {
        Name = name;
        Salary = salary;
    }

    public override string ToString()
    {
        return Name + " " + Salary;
    }

    public class Product
    {
        public string Name { get; set; }
        public double Price { get; set; }
        public Product(string name, double price)
        {
            Name = name;
            Price = price;
        }
        public override string ToString()
        {
            return Name + " " + Price;
        }

    }

    public class Student
    {
        public string Name { get; set; }
        public int Id { get; set; }
        public Student(string name, int id)
        {
            Name = name;
            Id = id;
        }
    }
}
        

    

    